$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("CriaMovimentacaoNaConta.feature");
formatter.feature({
  "line": 2,
  "name": "CRUD da movimentação da conta.",
  "description": "Como um usuario\r\neu quero cadastrar uma conta \r\ne inserir duas movimentações na conta\r\npara que possa altera-la, visualiza-la e exclui-la.",
  "id": "crud-da-movimentação-da-conta.",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Funcionais"
    },
    {
      "line": 1,
      "name": "@All"
    }
  ]
});
formatter.scenarioOutline({
  "line": 11,
  "name": "Cria movimentações na conta.",
  "description": "",
  "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 12,
  "name": "eu acessar o menu criar movimentacao",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "preencher o campo Tipo Movimentacao \u003ctpMovimentacao\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "preencher o campo Data Movimentacao \u003cdtMovimentacao\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "preencher o campo Data Pagamento \u003cdtPagamento\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "preencher o campo Descricao \u003cdescricao\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "preencher o campo Interessado \u003cinteressado\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "preencher o campo Valor \u003cvalor\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "preencher o campo Conta \u003cconta\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "selecionar o campo Situacao \u003csituacao\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "eu clicar no botao salvar",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "a mensagem \u003cmensagem\u003e sera exibida",
  "keyword": "Then "
});
formatter.examples({
  "line": 24,
  "name": "",
  "description": "",
  "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;",
  "rows": [
    {
      "cells": [
        "tpMovimentacao",
        "dtMovimentacao",
        "dtPagamento",
        "descricao",
        "interessado",
        "valor",
        "conta",
        "situacao",
        "mensagem"
      ],
      "line": 25,
      "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;;1"
    },
    {
      "cells": [
        "\"Receita\"",
        "\"01/04/2020\"",
        "\"03/04/2020\"",
        "\"Movimentacao 1\"",
        "\"InterTeste\"",
        "\"1000.65\"",
        "\"ContaCucumber\"",
        "\"Pago\"",
        "\"Movimentação adicionada com sucesso!\""
      ],
      "line": 26,
      "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;;2"
    },
    {
      "cells": [
        "\"Despesa\"",
        "\"01/04/2020\"",
        "\"05/04/2020\"",
        "\"Movimentacao 2\"",
        "\"InterTeste2\"",
        "\"5000.78\"",
        "\"ContaCucumber\"",
        "\"Pendente\"",
        "\"Movimentação adicionada com sucesso!\""
      ],
      "line": 27,
      "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;;3"
    },
    {
      "cells": [
        "\"Despesa\"",
        "\"01/04/2020\"",
        "\"05/04/2020\"",
        "\"Movimentacao 3\"",
        "\"InterTeste2\"",
        "\"25000.78\"",
        "\"ContaCucumber\"",
        "\"Pendente\"",
        "\"Movimentação adicionada com sucesso!\""
      ],
      "line": 28,
      "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 111200,
  "status": "passed"
});
formatter.background({
  "line": 8,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 9,
  "name": "estou logado no site",
  "keyword": "Given "
});
formatter.match({
  "location": "CriaMovimentacaoSteps.estouLogadoNoSite()"
});
formatter.result({
  "duration": 10342495500,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Cria movimentações na conta.",
  "description": "",
  "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Funcionais"
    },
    {
      "line": 1,
      "name": "@All"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "eu acessar o menu criar movimentacao",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "preencher o campo Tipo Movimentacao \"Receita\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "preencher o campo Data Movimentacao \"01/04/2020\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "preencher o campo Data Pagamento \"03/04/2020\"",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "preencher o campo Descricao \"Movimentacao 1\"",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "preencher o campo Interessado \"InterTeste\"",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "preencher o campo Valor \"1000.65\"",
  "matchedColumns": [
    5
  ],
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "preencher o campo Conta \"ContaCucumber\"",
  "matchedColumns": [
    6
  ],
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "selecionar o campo Situacao \"Pago\"",
  "matchedColumns": [
    7
  ],
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "eu clicar no botao salvar",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "a mensagem \"Movimentação adicionada com sucesso!\" sera exibida",
  "matchedColumns": [
    8
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "CriaMovimentacaoSteps.euAcessarOMenuCriarMovimentacao()"
});
formatter.result({
  "duration": 277106000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Receita",
      "offset": 37
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoTipoMovimentacao(String)"
});
formatter.result({
  "duration": 344650600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "01/04/2020",
      "offset": 37
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDataMovimentacao(String)"
});
formatter.result({
  "duration": 359833000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "03/04/2020",
      "offset": 34
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDataPagamento(String)"
});
formatter.result({
  "duration": 350028200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Movimentacao 1",
      "offset": 29
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDescricao(String)"
});
formatter.result({
  "duration": 351213700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "InterTeste",
      "offset": 31
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoInteressado(String)"
});
formatter.result({
  "duration": 349157900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1000.65",
      "offset": 25
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoValor(String)"
});
formatter.result({
  "duration": 340241100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "ContaCucumber",
      "offset": 25
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoConta(String)"
});
formatter.result({
  "duration": 333470000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Pago",
      "offset": 29
    }
  ],
  "location": "CriaMovimentacaoSteps.selecionarOCampoSituacao(String)"
});
formatter.result({
  "duration": 339915900,
  "status": "passed"
});
formatter.match({
  "location": "CriaMovimentacaoSteps.euClicarNoBotaoSalvar()"
});
formatter.result({
  "duration": 631079900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Movimentação adicionada com sucesso!",
      "offset": 12
    }
  ],
  "location": "CriaMovimentacaoSteps.aMensagemSeraExibida(String)"
});
formatter.result({
  "duration": 909178800,
  "status": "passed"
});
formatter.after({
  "duration": 1286763700,
  "status": "passed"
});
formatter.after({
  "duration": 3107142200,
  "status": "passed"
});
formatter.before({
  "duration": 31900,
  "status": "passed"
});
formatter.background({
  "line": 8,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 9,
  "name": "estou logado no site",
  "keyword": "Given "
});
formatter.match({
  "location": "CriaMovimentacaoSteps.estouLogadoNoSite()"
});
formatter.result({
  "duration": 9396466000,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "Cria movimentações na conta.",
  "description": "",
  "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Funcionais"
    },
    {
      "line": 1,
      "name": "@All"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "eu acessar o menu criar movimentacao",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "preencher o campo Tipo Movimentacao \"Despesa\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "preencher o campo Data Movimentacao \"01/04/2020\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "preencher o campo Data Pagamento \"05/04/2020\"",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "preencher o campo Descricao \"Movimentacao 2\"",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "preencher o campo Interessado \"InterTeste2\"",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "preencher o campo Valor \"5000.78\"",
  "matchedColumns": [
    5
  ],
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "preencher o campo Conta \"ContaCucumber\"",
  "matchedColumns": [
    6
  ],
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "selecionar o campo Situacao \"Pendente\"",
  "matchedColumns": [
    7
  ],
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "eu clicar no botao salvar",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "a mensagem \"Movimentação adicionada com sucesso!\" sera exibida",
  "matchedColumns": [
    8
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "CriaMovimentacaoSteps.euAcessarOMenuCriarMovimentacao()"
});
formatter.result({
  "duration": 257208100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Despesa",
      "offset": 37
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoTipoMovimentacao(String)"
});
formatter.result({
  "duration": 354991300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "01/04/2020",
      "offset": 37
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDataMovimentacao(String)"
});
formatter.result({
  "duration": 353684400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "05/04/2020",
      "offset": 34
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDataPagamento(String)"
});
formatter.result({
  "duration": 346748700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Movimentacao 2",
      "offset": 29
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDescricao(String)"
});
formatter.result({
  "duration": 353946900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "InterTeste2",
      "offset": 31
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoInteressado(String)"
});
formatter.result({
  "duration": 347219800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5000.78",
      "offset": 25
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoValor(String)"
});
formatter.result({
  "duration": 341860900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "ContaCucumber",
      "offset": 25
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoConta(String)"
});
formatter.result({
  "duration": 331189900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Pendente",
      "offset": 29
    }
  ],
  "location": "CriaMovimentacaoSteps.selecionarOCampoSituacao(String)"
});
formatter.result({
  "duration": 336901800,
  "status": "passed"
});
formatter.match({
  "location": "CriaMovimentacaoSteps.euClicarNoBotaoSalvar()"
});
formatter.result({
  "duration": 573433800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Movimentação adicionada com sucesso!",
      "offset": 12
    }
  ],
  "location": "CriaMovimentacaoSteps.aMensagemSeraExibida(String)"
});
formatter.result({
  "duration": 907165000,
  "status": "passed"
});
formatter.after({
  "duration": 1291971800,
  "status": "passed"
});
formatter.after({
  "duration": 3104181200,
  "status": "passed"
});
formatter.before({
  "duration": 31900,
  "status": "passed"
});
formatter.background({
  "line": 8,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 9,
  "name": "estou logado no site",
  "keyword": "Given "
});
formatter.match({
  "location": "CriaMovimentacaoSteps.estouLogadoNoSite()"
});
formatter.result({
  "duration": 8778348800,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Cria movimentações na conta.",
  "description": "",
  "id": "crud-da-movimentação-da-conta.;cria-movimentações-na-conta.;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@Funcionais"
    },
    {
      "line": 1,
      "name": "@All"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "eu acessar o menu criar movimentacao",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "preencher o campo Tipo Movimentacao \"Despesa\"",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "preencher o campo Data Movimentacao \"01/04/2020\"",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "preencher o campo Data Pagamento \"05/04/2020\"",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "preencher o campo Descricao \"Movimentacao 3\"",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "preencher o campo Interessado \"InterTeste2\"",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "preencher o campo Valor \"25000.78\"",
  "matchedColumns": [
    5
  ],
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "preencher o campo Conta \"ContaCucumber\"",
  "matchedColumns": [
    6
  ],
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "selecionar o campo Situacao \"Pendente\"",
  "matchedColumns": [
    7
  ],
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "eu clicar no botao salvar",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "a mensagem \"Movimentação adicionada com sucesso!\" sera exibida",
  "matchedColumns": [
    8
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "CriaMovimentacaoSteps.euAcessarOMenuCriarMovimentacao()"
});
formatter.result({
  "duration": 263338100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Despesa",
      "offset": 37
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoTipoMovimentacao(String)"
});
formatter.result({
  "duration": 353530300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "01/04/2020",
      "offset": 37
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDataMovimentacao(String)"
});
formatter.result({
  "duration": 351485300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "05/04/2020",
      "offset": 34
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDataPagamento(String)"
});
formatter.result({
  "duration": 345655200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Movimentacao 3",
      "offset": 29
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoDescricao(String)"
});
formatter.result({
  "duration": 350515200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "InterTeste2",
      "offset": 31
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoInteressado(String)"
});
formatter.result({
  "duration": 347606500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "25000.78",
      "offset": 25
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoValor(String)"
});
formatter.result({
  "duration": 342158300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "ContaCucumber",
      "offset": 25
    }
  ],
  "location": "CriaMovimentacaoSteps.preencherOCampoConta(String)"
});
formatter.result({
  "duration": 331915500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Pendente",
      "offset": 29
    }
  ],
  "location": "CriaMovimentacaoSteps.selecionarOCampoSituacao(String)"
});
formatter.result({
  "duration": 334161500,
  "status": "passed"
});
formatter.match({
  "location": "CriaMovimentacaoSteps.euClicarNoBotaoSalvar()"
});
formatter.result({
  "duration": 584224800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Movimentação adicionada com sucesso!",
      "offset": 12
    }
  ],
  "location": "CriaMovimentacaoSteps.aMensagemSeraExibida(String)"
});
formatter.result({
  "duration": 906955000,
  "status": "passed"
});
formatter.after({
  "duration": 1258718600,
  "status": "passed"
});
formatter.after({
  "duration": 3104369200,
  "status": "passed"
});
});